//! Deterministic complete defaults and private in-place initialization helpers.
//! Warning examples are synthetic-only; source catalogue selections do not qualify vehicle traffic.
use crate::*;

/// Return a default widget for `channel`, retaining caller-supplied `id`, `view` and `placement`.
/// Caller geometry/IDs are not validated here. Warnings are reviewed synthetic examples,
/// not recommended engine limits; boost warning defaults off. Built-in ASCII lengths are asserted.
pub fn default_widget(
    channel: Channel,
    id: u16,
    view: u8,
    placement: Placement,
) -> Widget {
    let (mode, trigger, clear) = match channel {
        Channel::Water => (LimitMode::High, 110.0, 105.0),
        Channel::Oil => (LimitMode::High, 130.0, 125.0),
        Channel::Dsg => (LimitMode::High, 120.0, 115.0),
        Channel::Iat => (LimitMode::High, 60.0, 55.0),
        Channel::Egt => (LimitMode::High, 1050.0, 1000.0),
        Channel::Battery => (LimitMode::Low, 11.5, 12.0),
        Channel::Lambda => (LimitMode::LambdaDeviation, 0.15, 0.05),
        Channel::Boost => (LimitMode::High, 2.5, 2.3),
    };
    Widget {
        id,
        view,
        channel: channel.into(),
        placement,
        label: channel.label().try_into().expect("bounded built-in label"),
        gauge: Gauge::for_channel(channel),
        colors: WidgetColors::default(),
        advanced: AdvancedDisplay::for_channel(channel, channel == Channel::Lambda),
        display: DisplayOptions {
            decimals: match channel {
                Channel::Boost => 2,
                Channel::Battery => 1,
                Channel::Lambda => 3,
                _ => 0,
            },
            graph: channel != Channel::Boost,
            average: !matches!(channel, Channel::Boost | Channel::Lambda | Channel::Battery),
            extrema: channel != Channel::Lambda,
            trend: !matches!(channel, Channel::Boost | Channel::Lambda),
            afr: channel == Channel::Lambda,
            graph_range: GraphRange::Auto,
        },
        warning: WarningSettings {
            enabled: channel != Channel::Boost,
            applicability: Applicability::DemoOnly,
            mode,
            trigger,
            clear,
            min_load_percent: 60.0,
            on_ms: 1000,
            off_ms: 500,
            message: channel.label().try_into().expect("bounded built-in warning"),
            advanced: AdvancedWarning::DEFAULT,
        },
    }
}

/// Return the complete one-view, eight-cell landscape default with disabled BLE.
/// Defaults are editable candidates; callers seeking runtime proof must still validate them.
pub fn default_config() -> Config {
    let mut config = empty_config();
    fill_default_config(&mut config);
    config
}

/// Return legally initialized storage only, not an admitted document or public default.
/// Private slots must replace and validate all placeholders before publication.
pub(crate) const fn empty_config() -> Config {
    Config {
        version: 0,
        catalogue_version: 0,
        boot_view: 0,
        views: heapless::Vec::new(),
        widgets: heapless::Vec::new(),
        sources: [ChannelSource {
            definition: DefinitionId::Disabled,
            access: Access::None,
            decoder: Decoder::None,
            evidence: Evidence::Disabled,
            route: Route::Unknown,
            poll: Poll::Off,
            freshness_ms: 0,
        }; 8],
        warnings: WarningPresentation {
            scope: WarningScope::AllViews,
            mode: WarningMode::CycleOne,
            page_ms: 0,
        },
        fuel: Fuel::EquivalentGasoline,
        warning_colors: WarningColors {
            foreground: Color(0),
            background: Color(0),
        },
        history_seconds: [120; 8],
        reduced_motion: false,
        led: LedSettings::DEFAULT,
        orientation: Orientation::Landscape,
        ble: BleSettings::DEFAULT,
        controls: ControlMap {
            hold_ms: 0,
            screens: [ScreenBindings {
                buttons: [ButtonBinding {
                    tap: ControlAction::None,
                    hold: ControlAction::None,
                }; 4],
                encoder_rotation: RotationAction::None,
                encoder_click: ControlAction::None,
            }; 3],
        },
    }
}

/// Replace every field in `config` in place with complete defaults, clearing old collections.
/// Avoids a second full-size model temporary. Panics only on impossible reviewed built-in
/// string/capacity drift; no previous candidate field survives a successful fill.
pub(crate) fn fill_default_config(config: &mut Config) {
    config.ble = BleSettings::DEFAULT;
    config.version = VERSION;
    config.catalogue_version = CATALOGUE_VERSION;
    config.boot_view = 1;
    config.views.clear();
    if config
        .views
        .push(View {
            id: 1,
            name: "Overview".try_into().expect("bounded built-in view"),
            orientation: None,
        })
        .is_err()
    {
        panic!("built-in view count");
    }
    config.widgets.clear();
    for (slot, channel) in [
        Channel::Boost,
        Channel::Lambda,
        Channel::Battery,
        Channel::Water,
        Channel::Oil,
        Channel::Dsg,
        Channel::Iat,
        Channel::Egt,
    ]
    .into_iter()
    .enumerate()
    {
        if config
            .widgets
            .push(default_widget(
                channel,
                slot as u16 + 1,
                1,
                Placement {
                    column: (slot % 4) as u8,
                    row: (slot / 4) as u8,
                    span: Span::OneByOne,
                },
            ))
            .is_err()
        {
            panic!("built-in widget count");
        }
    }
    use DefinitionId::*;
    let ids = [
        ObdMapMinusAmbient,
        ObdOil5c,
        ObdCoolant05,
        DsgOil2104,
        ObdIntake0f,
        UnresolvedEgt,
        ObdVoltage42,
        SimosLambda10c0,
    ];
    for (i, id) in ids.into_iter().enumerate() {
        config.sources[i] = definition(id).source(Channel::ALL[i]);
    }
    config.warnings = WarningPresentation {
        scope: WarningScope::AllViews,
        mode: WarningMode::CycleOne,
        page_ms: 2000,
    };
    config.fuel = Fuel::EquivalentGasoline;
    config.warning_colors = WarningColors::default();
    config.controls = ControlMap::default();
    config.history_seconds = [120; 8];
    config.reduced_motion = false;
    config.led = LedSettings::DEFAULT;
    config.orientation = Orientation::Landscape;
}

/// Return the group widget with caller `id`, `view` and `placement`, without validating their geometry.
/// Defaults show simultaneous status/number at one decimal and a global DemoOnly ignition warning.
/// Shared trigger/clear zero means strictly negative degrees trigger and zero clears after dwell.
/// Dormant degree bounds are representation limits, not recommended engine limits.
pub fn default_ignition_widget(
    id: u16,
    view: u8,
    placement: Placement,
) -> Widget {
    Widget {
        id,
        view,
        channel: WidgetChannel::IgnitionRetard,
        placement,
        label: "IGN RETARD".try_into().expect("bounded built-in label"),
        display: DisplayOptions {
            decimals: 1,
            graph: false,
            average: false,
            extrema: false,
            trend: false,
            afr: false,
            graph_range: GraphRange::Auto,
        },
        warning: WarningSettings {
            enabled: true,
            applicability: Applicability::DemoOnly,
            mode: LimitMode::Low,
            trigger: 0.0,
            clear: 0.0,
            min_load_percent: 0.0,
            on_ms: 1000,
            off_ms: 500,
            message: "Ignition retarded".try_into().expect("bounded built-in warning"),
            advanced: AdvancedWarning::DEFAULT,
        },
        gauge: Gauge {
            kind: GaugeKind::Numeric,
            min: -327.68,
            max: 327.67,
            expand: false,
        },
        colors: WidgetColors::default(),
        advanced: AdvancedDisplay::for_ignition(),
    }
}

/// Return scalar or group defaults for `channel`, preserving caller `id`, `view`
/// and `placement` without validating their identity or geometry.
pub fn default_widget_for_channel(
    channel: WidgetChannel,
    id: u16,
    view: u8,
    placement: Placement,
) -> Widget {
    match channel.scalar() {
        Some(scalar) => default_widget(scalar, id, view, placement),
        None => default_ignition_widget(id, view, placement),
    }
}
