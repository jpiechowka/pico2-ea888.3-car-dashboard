//! Legacy relative-boost cell with explicit alternate units and optional decorative feedback.
use embedded_graphics::mono_font::MonoTextStyle;
use embedded_graphics::pixelcolor::Rgb565;
use embedded_graphics::prelude::*;
use embedded_graphics::text::Text;

use super::value_style_for_color;
use crate::ui::{BLACK, CENTERED, LABEL_FONT, LABEL_STYLE_ORANGE, LABEL_STYLE_WHITE, PINK, WHITE};
use crate::widgets::primitives::draw_cell_background;

#[allow(clippy::too_many_arguments)]
/// Draws into `display` at bounded panel pixel `x`, `y`, width `w`, height `h`.
/// `boost_bar` and `max_boost` are relative bar; `show_psi` selects primary units.
/// `show_easter_egg` replaces maximum text with decorative feedback whose colors
/// follow `blink_on`; `shake_offset` moves only the primary value horizontally.
/// Caller supplies fitting geometry/values and clipping; arithmetic is not an
/// arbitrary-coordinate API and target errors are discarded.
pub fn draw_boost_cell<D>(
    display: &mut D,
    x: u32,
    y: u32,
    w: u32,
    h: u32,
    boost_bar: f32,
    max_boost: f32,
    show_psi: bool,
    show_easter_egg: bool,
    blink_on: bool,
    shake_offset: i32,
) where
    D: DrawTarget<Color = Rgb565>,
{
    draw_cell_background(display, x, y, w, h, BLACK);

    let center_x = (x + w / 2) as i32;
    let center_y = (y + h / 2) as i32;
    let value_x = center_x + shake_offset;

    Text::with_text_style(
        "BOOST REL",
        Point::new(center_x, y as i32 + 14),
        LABEL_STYLE_WHITE,
        CENTERED,
    )
    .draw(display)
    .ok();

    let text = crate::widgets::cell_text::boost(boost_bar, max_boost, show_psi);
    let value_color = if show_easter_egg {
        if blink_on { PINK } else { WHITE }
    } else {
        WHITE
    };
    let value_style = value_style_for_color(value_color);
    Text::with_text_style(&text[0], Point::new(value_x, center_y - 8), value_style, CENTERED)
        .draw(display)
        .ok();

    let unit_label = if show_psi { "PSI" } else { "BAR" };
    Text::with_text_style(
        unit_label,
        Point::new(center_x, center_y + 10),
        LABEL_STYLE_WHITE,
        CENTERED,
    )
    .draw(display)
    .ok();

    Text::with_text_style(
        &text[1],
        Point::new(center_x, center_y + 22),
        LABEL_STYLE_WHITE,
        CENTERED,
    )
    .draw(display)
    .ok();

    if show_easter_egg {
        let easter_color = if blink_on { WHITE } else { PINK };
        let easter_style = MonoTextStyle::new(LABEL_FONT, easter_color);
        Text::with_text_style(
            "Fast AF Boi!",
            Point::new(center_x, (y + h) as i32 - 8),
            easter_style,
            CENTERED,
        )
        .draw(display)
        .ok();
    } else {
        Text::with_text_style(
            &text[2],
            Point::new(center_x, (y + h) as i32 - 8),
            LABEL_STYLE_ORANGE,
            CENTERED,
        )
        .draw(display)
        .ok();
    }
}
