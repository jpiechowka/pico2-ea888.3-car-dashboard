//! In-place boot admission without a second full-size configuration temporary.
use super::{ValidatedConfig, validate_ref};
use crate::BootConfig;
use crate::codec::decode_current_into;
use crate::defaults::{empty_config, fill_default_config};

/// Initialized, unpublished storage for one bounded configuration.
///
/// Loading fills this storage directly. Only a complete, canonical and
/// semantically validated document (or the reviewed default) is published.
/// The current envelope is required even when host JSON migration is enabled.
/// Place `ConfigSlot::new()` in constant static storage for firmware; a local
/// slot still occupies a full configuration on its caller's stack.
///
/// Storage is private and the slot has no unchecked or mutable accessor:
/// ```compile_fail
/// let slot = dashboard_config::ConfigSlot::new();
/// let config = slot.storage;
/// ```
/// A published borrow prevents reloading until its last use:
/// ```compile_fail
/// let mut slot = dashboard_config::ConfigSlot::new();
/// let first = slot.load_at_boot(b"");
/// let second = slot.load_at_boot(b"");
/// assert_eq!(first.fault, second.fault);
/// ```
pub struct ConfigSlot {
    /// Legally initialized unpublished storage; failed partial decode refills every field
    /// before this wrapper is exposed through a validated borrow.
    storage: BootConfig,
}

impl ConfigSlot {
    /// Return initialized unpublished storage suitable for a firmware `static` initializer.
    /// The placeholder is intentionally invalid and has no public accessor until admission.
    pub const fn new() -> Self {
        Self {
            storage: BootConfig {
                config: ValidatedConfig {
                    config: empty_config(),
                    stoich: 0.0,
                    cache_identity: None,
                    cache_status: crate::CacheIdentityStatus::Untracked,
                },
                fault: None,
            },
        }
    }

    /// Admit current-format `bytes` directly into the slot and return a borrow of the result.
    /// Any decode/canonical/validation failure completely restores reviewed defaults and
    /// retains the fault. Reload needs exclusive access; old borrows cannot survive it.
    /// Fresh cache issuance follows success/fallback; exhaustion preserves validity.
    /// Panics only if reviewed defaults violate validation; no host legacy migration occurs.
    #[inline(never)]
    pub fn load_at_boot(
        &mut self,
        bytes: &[u8],
    ) -> &BootConfig {
        match decode_current_into(bytes, &mut self.storage.config.config) {
            Ok(stoich) => {
                self.storage.config.stoich = stoich;
                self.storage.fault = None;
            }
            Err(fault) => {
                fill_default_config(&mut self.storage.config.config);
                self.storage.config.stoich =
                    validate_ref(&self.storage.config.config).expect("reviewed default configuration");
                self.storage.fault = Some(fault);
            }
        }
        self.storage.config.publish_identity();
        &self.storage
    }
}

impl Default for ConfigSlot {
    /// Return fresh unpublished storage, equivalent to [`Self::new`].
    fn default() -> Self { Self::new() }
}

// Config plus proof/fault metadata; whole-image RAM/stack checks run separately.
#[cfg(target_pointer_width = "32")]
/// Target slot storage ceiling; stack placement and whole-image headroom need separate checks.
const _: () = assert!(core::mem::size_of::<ConfigSlot>() <= 14_620);
