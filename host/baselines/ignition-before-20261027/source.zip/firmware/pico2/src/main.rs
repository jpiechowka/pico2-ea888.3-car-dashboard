//! Pico 2 W dashboard boot and core0 control/render integration.
//! Two affine framebuffers cross a capacity-one SPI task boundary; all UI/LED
//! completion effects use the matching transfer token. Core1 owns acquisition.
//! Flash saves drain display ownership and park participating owners before ROM
//! mutation; receive timeouts never cancel DMA. Hardware faults retain owners
//! until watchdog recovery. Default vehicle channels remain unavailable.
#![no_std]
#![no_main]
#![allow(clippy::cast_possible_truncation)]
#![allow(clippy::cast_precision_loss)]
#![allow(clippy::cast_possible_wrap)]
#![allow(clippy::cast_sign_loss)]

/// Once-per-boot reporting of bounded cache identity exhaustion.
mod cache_reporting;
/// Exclusive hardware adapters for panel, LEDs, flash and watchdog.
mod drivers;
/// Optional encoder polling and bounded event publication.
mod peripherals;
/// Cycle/stack/log observations and optional diagnostic exports.
mod profiling;
/// Incremental Debug and Logs rendering from coherent snapshots.
mod screens;
/// Shared page and application-state compatibility exports.
mod state;
/// Cross-core acquisition, display and finite maintenance supervision.
mod tasks;
/// Shared visual constants and UI compatibility exports.
mod ui;
/// One-time embedded configuration parsing before task startup.
mod view_config;

/// Shared configuration constants used by the hardware adapters.
mod config {
    pub use dashboard_pico2::config::*;
}
use core::sync::atomic::Ordering;

use dashboard_pico2::acquisition::{DashboardSnapshot, ResetRequests};
use dashboard_pico2::backlight::Backlight;
use dashboard_pico2::control_session::ControlSession;
use dashboard_pico2::controls::ControlGestures;
use dashboard_pico2::dashboard::{DashboardCache, DashboardScene, Overlay};
use dashboard_pico2::diagnostic_values::{FrameWorkObservation, memory_kib, rate_text, work_text};
use dashboard_pico2::display::FrameBuffer;
use dashboard_pico2::display::damage::{DamagePlan, PanelHistory};
use dashboard_pico2::display::pipeline::{FrameLease, FrameLifecycle};
use dashboard_pico2::display::telemetry::{CompletionRate, FrameTrace, RenderTrace};
use dashboard_pico2::settings::Settings;
use dashboard_pico2::settings::policy::Policy;
use dashboard_pico2::status_led::{LedController, PresentedLed, PresentedScene};
use dashboard_pico2::warning_state::{WarningFeedback, WarningRequests};
use defmt_rtt as _;
use embassy_executor::{Executor, Spawner};
use embassy_rp::bind_interrupts;
use embassy_rp::dma::InterruptHandler as DmaInterruptHandler;
use embassy_rp::gpio::{Input, Level, Output, Pull};
use embassy_rp::i2c::{self, InterruptHandler as I2cInterruptHandler};
use embassy_rp::pwm::{Config as PwmConfig, Pwm};
use embassy_rp::spi::Spi;
use embassy_time::{Duration, Instant, Timer};
use embedded_graphics::prelude::*;
use panic_probe as _;
use static_cell::{ConstStaticCell, StaticCell};

use crate::config::backlight::{PWM_TOP, pwm_divider, pwm_frequency_hz};
use crate::drivers::{St7789Flusher, St7789Renderer, display_spi_config, get_actual_spi_freq};
use crate::peripherals::{ENCODER_EVENTS, encoder_task};
use crate::profiling as cpu_profiling;
use crate::screens::{ProfilingData, draw_logs_page, draw_profiling_page};
use crate::state::Page;
use crate::tasks::{
    BUFFER_SWAPS,
    BUFFER_WAITS,
    COMPLETED_FRAMES,
    CORE1_STACK,
    DASHBOARD_VALUES,
    EXECUTOR_CORE1,
    FLUSH_BUFFER_IDX,
    FLUSH_REQUESTS,
    acquisition_task,
    display_flush_task,
    wait_completed,
    wait_started,
};
use crate::ui::BLACK;

// These exact arrays are consumed at runtime and independently checked in the ELF.
#[used]
#[unsafe(no_mangle)]
#[unsafe(link_section = ".startup_profile")]
/// Exact encoded startup policy retained for independent linked-image admission.
static DASHBOARD_STARTUP_PROFILE: [u8; 16] = *include_bytes!(concat!(env!("OUT_DIR"), "/startup_profile.bin"));
/// Original converted-asset byte length, excluding the retained sentinel.
const STARTUP_ASSET_LENGTH: usize = include_bytes!(concat!(env!("OUT_DIR"), "/startup_asset.bin")).len();
#[used]
#[unsafe(no_mangle)]
#[unsafe(link_section = ".startup_asset")]
/// Converted bounded artwork plus one zero sentinel; parsers exclude the sentinel.
static DASHBOARD_STARTUP_ASSET: [u8; STARTUP_ASSET_LENGTH + 1] = {
    // A retained zero sentinel gives even an absent asset a concrete linked object.
    // The runtime parser receives only the original asset bytes.
    let source = include_bytes!(concat!(env!("OUT_DIR"), "/startup_asset.bin"));
    let mut bytes = [0; STARTUP_ASSET_LENGTH + 1];
    let mut index = 0;
    while index != STARTUP_ASSET_LENGTH {
        bytes[index] = source[index];
        index += 1;
    }
    bytes
};

#[unsafe(link_section = ".bi_entries")]
#[used]
/// Read-only picotool name/description/version/build metadata; no runtime authority.
pub static PICOTOOL_ENTRIES: [embassy_rp::binary_info::EntryAddr; 4] = [
    embassy_rp::binary_info::rp_program_name!(c"pico2-dashboard"),
    embassy_rp::binary_info::rp_program_description!(c"OBD-II Dashboard for EA888.3 on PIM715 Display"),
    embassy_rp::binary_info::rp_cargo_version!(),
    embassy_rp::binary_info::rp_program_build_attribute!(),
];

/// Applies `backlight` compare to owned `pwm` only when cached `config` changes;
/// preserves the configured divider/TOP and performs no feedback timing itself.
fn apply_backlight(
    pwm: &mut Pwm<'_>,
    config: &mut PwmConfig,
    backlight: &Backlight,
) {
    if config.compare_a != backlight.compare() {
        config.compare_a = backlight.compare();
        pwm.set_config(config);
    }
}

/// Evaluates configured LED policy in `controller` from completed `presentation`,
/// current `backlight`, and `config`, then applies light duty to owned `rgb`.
/// Uses monotonic milliseconds; queued/uncompleted warnings do not become visible.
fn apply_indicator(
    rgb: &mut drivers::rgb_led::RgbLed<'_>,
    controller: &mut LedController,
    presentation: &PresentedLed,
    backlight: &Backlight,
    config: &dashboard_pico2::view_config::Config,
) {
    rgb.apply(controller.update(
        &config.led,
        presentation.visible(),
        backlight.compare() != 0,
        Instant::now().as_millis(),
        config.reduced_motion,
    ));
}

/// Returns the admitted RP2350 VSEL setting in millivolts, or None for an invalid
/// encoding; this register observation is not an ADC/electrical measurement.
fn vreg_setting_mv() -> Option<u32> {
    // HAL validates the RP2350 VSEL encoding. This is a setting, not an ADC reading.
    embassy_rp::clocks::core_voltage()
        .ok()
        .map(|voltage| 550 + u32::from(voltage as u8) * 50)
}

/// Returns Demo only for the explicit demo feature; otherwise returns Vehicle
/// even when no qualified transport can publish live measurements.
fn data_mode() -> dashboard_pico2::samples::DataMode {
    if cfg!(feature = "demo") {
        dashboard_pico2::samples::DataMode::Demo
    } else {
        dashboard_pico2::samples::DataMode::Vehicle
    }
}

/// Logs `error` with retained HAL/JEDEC detail; debug-build rejection is an Info
/// volatile-settings notice. Does not retry, clear state, or mutate flash.
fn log_settings_error(error: &drivers::settings_flash::JournalError) {
    use dashboard_pico2::settings::Error as JournalError;
    use drivers::settings_flash::Error;
    match error {
        JournalError::Storage(Error::Hardware(cause)) => log_fault!("Flash: {:?}", cause),
        JournalError::Storage(Error::Identity(id)) => log_fault!("Unknown flash: {:06x}", id),
        JournalError::Storage(Error::DebugBuild) => log_info!("Debug settings: volatile"),
        _ => log_fault!("Settings: {:?}", error),
    }
}

#[cfg(any(
    all(feature = "demo", feature = "longan-rx12"),
    all(feature = "demo", feature = "ble-obd"),
    all(feature = "longan-rx12", feature = "ble-obd")
))]
compile_error!("Select exactly one acquisition backend: demo, ble-obd or longan-rx12");

/// Starts core1 DWT profiling at `cpu_freq_hz` and runs acquisition forever.
/// `animation_start` anchors synthetic time; `stack_bottom`/`stack_top` bound
/// stack observations, and `resources` transfers uninitialized source ownership.
/// Panics on executor/task allocation failure; no return path releases owners.
fn core1_main(
    animation_start: Instant,
    cpu_freq_hz: u32,
    stack_bottom: u32,
    stack_top: u32,
    resources: tasks::acquisition::Resources,
) -> ! {
    cpu_profiling::init(cpu_freq_hz);
    let executor = EXECUTOR_CORE1.init(Executor::new());
    executor.run(|spawner| {
        spawner.spawn(acquisition_task(animation_start, stack_bottom, stack_top, resources).unwrap());
    })
}

bind_interrupts!(
/// Core0 DMA0 display, optional DMA1/PIO0 radio, and I2C0 interrupt bindings.
struct Irqs {
    DMA_IRQ_0 => DmaInterruptHandler<embassy_rp::peripherals::DMA_CH0>,
        #[cfg(feature = "ble-obd")] DmaInterruptHandler<embassy_rp::peripherals::DMA_CH1>;
    I2C0_IRQ => I2cInterruptHandler<embassy_rp::peripherals::I2C0>;
    #[cfg(feature = "ble-obd")]
    PIO0_IRQ_0 => embassy_rp::pio::InterruptHandler<embassy_rp::peripherals::PIO0>;
});

#[embassy_executor::main]
/// Parses configuration once, then uses `spawner` to enqueue the large dashboard
/// task so its poll frame is absent during parsing. Returns after enqueue; panics
/// on task allocation failure. No hardware is initialized by this boot shim.
async fn main(spawner: Spawner) {
    // Configuration parsing must finish before the large dashboard poll frame
    // becomes resident. spawn only enqueues; Embassy polls this task after the
    // boot task returns. Do not replace this boundary with an async await.
    let configuration = view_config::initialize();
    spawner.spawn(dashboard_task(spawner, configuration).unwrap());
}

#[embassy_executor::task]
/// Owns core0 hardware/control/render state indefinitely after boot admission.
/// `spawner` launches sole peripheral owners; immutable `dashboard_configuration`
/// supplies accepted settings and explicit fallback evidence. Boot qualifies flash
/// before core1, initializes panel/encoder, then renders token-bound presentations.
/// Errors retain prior valid settings or exit startup where supported; ownership,
/// timing and transfer invariant violations panic for independent watchdog recovery.
/// Never cancel this future: it may own buffers or a maintenance ticket.
async fn dashboard_task(
    spawner: Spawner,
    dashboard_configuration: &'static dashboard_pico2::view_config::BootConfig,
) {
    log_info!("OBD-II Dashboard starting");

    let p = {
        // Pico 2 W: GP23/24/25/29 belong to wireless/VSYS, not LED/VBUS/SMPS.
        // The optional BLE task owns these pins; PIM715 RGB uses GP26/27/28.
        let mut config = embassy_rp::config::Config::default();
        config.clocks = dashboard_pico2::clock_profile::clock_config();
        log_info!(
            "Clock request CPU {} Hz/SPI {} Hz; resolved CPU {} Hz/SPI {} Hz; VSEL {} mV",
            dashboard_pico2::clock_profile::REQUESTED_CPU_HZ,
            dashboard_pico2::clock_profile::REQUESTED_SPI_HZ,
            dashboard_pico2::clock_profile::ACTUAL_CPU_HZ,
            dashboard_pico2::clock_profile::ACTUAL_SPI_HZ,
            dashboard_pico2::clock_profile::VOLTAGE_MV
        );

        embassy_rp::init(config)
    };

    let watchdog = crate::drivers::watchdog::RecoveryWatchdog::start(p.WATCHDOG);
    let reset_cause = watchdog.reset_label();
    log_info!("Previous reset: {}", reset_cause);
    let mut warning_pager = dashboard_pico2::view_state::WarningPager::new();
    let mut dashboard_layout = dashboard_pico2::configured_scene::Layout::new(
        &dashboard_configuration.config,
        dashboard_configuration.config.config().boot_view,
        dashboard_configuration.fault.is_some(),
    )
    .expect("validated boot view");
    log_info!("Dashboard config SHA256: {}", view_config::SHA256);
    if let Some(fault) = dashboard_configuration.fault {
        log_fault!("Configuration fallback: {:?}", fault);
    }
    let cpu_freq_hz = embassy_rp::clocks::clk_sys_freq();

    let mut settings_flash = drivers::settings_flash::SettingsFlash::new(p.FLASH);
    let (initial_settings, mut has_saved_settings, settings_enabled) = match settings_flash.load() {
        Ok(loaded) => (loaded.unwrap_or_default(), loaded.is_some(), true),
        Err(error) => {
            log_settings_error(&error);
            (Settings::default(), false, false)
        }
    };
    let initial_settings = initial_settings.for_boot();
    let mut settings_policy = if settings_enabled {
        Policy::new(initial_settings, Instant::now().as_millis())
    } else {
        Policy::disabled(initial_settings, Instant::now().as_millis())
    };
    let mut pending_save = None;
    let mut last_settings_status = settings_policy.status();
    log_info!("Settings: {}", last_settings_status.label(has_saved_settings));

    let animation_start = Instant::now();
    let stack = CORE1_STACK.init(embassy_rp::multicore::Stack::new());
    let stack_bottom = stack.mem.as_ptr() as u32;
    let stack_top = stack_bottom
        .checked_add(stack.mem.len() as u32)
        .expect("invalid core1 stack bounds");
    let acquisition_resources = tasks::acquisition::Resources {
        configuration: &dashboard_configuration.config,
        #[cfg(feature = "longan-rx12")]
        uart: drivers::longan::Resources {
            uart: p.UART0,
            tx: p.PIN_0,
            rx: p.PIN_1,
        },
    };
    embassy_rp::multicore::spawn_core1(p.CORE1, stack, move || {
        core1_main(
            animation_start,
            cpu_freq_hz,
            stack_bottom,
            stack_top,
            acquisition_resources,
        );
    });

    cpu_profiling::init(cpu_freq_hz);

    let mut rgb_led = drivers::rgb_led::RgbLed::new(p.PWM_SLICE5, p.PIN_26, p.PIN_27, p.PWM_SLICE6, p.PIN_28);
    let mut led_controller = LedController::new();
    rgb_led.apply(led_controller.update(
        &dashboard_configuration.config.config().led,
        PresentedScene::EMPTY,
        true,
        Instant::now().as_millis(),
        dashboard_configuration.config.config().reduced_motion,
    ));

    let cs = Output::new(p.PIN_17, Level::High);
    let dc = Output::new(p.PIN_16, Level::Low);

    // Backlight via PWM for brightness control (GP20 = PWM slice 2, channel A)
    let mut session = ControlSession::new(
        &dashboard_configuration.config,
        initial_settings.fps(),
        initial_settings.boost_psi(),
    );
    let backlight_divider = pwm_divider(cpu_freq_hz).expect("Unsupported backlight PWM clock");
    let mut pwm_config = PwmConfig::default();
    pwm_config.top = PWM_TOP;
    pwm_config.divider = backlight_divider.into();
    pwm_config.compare_a = session.backlight().compare();
    let mut backlight_pwm = Pwm::new_output_a(p.PWM_SLICE2, p.PIN_20, pwm_config.clone());
    log_info!(
        "Configured CPU {} Hz, backlight PWM {} Hz",
        cpu_freq_hz,
        pwm_frequency_hz(cpu_freq_hz, backlight_divider)
    );

    let spi = Spi::new_txonly(p.SPI0, p.PIN_18, p.PIN_19, p.DMA_CH0, Irqs, display_spi_config());

    let mut flusher = St7789Flusher::new(spi, dc, cs);
    flusher.init().await.expect("display initialization failed");

    log_info!("Display initialized");

    /// First fixed 153600-byte framebuffer, taken once into an affine lease.
    static FRAME_A: ConstStaticCell<FrameBuffer> = ConstStaticCell::new(FrameBuffer::new());
    /// Second fixed framebuffer; no transpose or third framebuffer is allocated.
    static FRAME_B: ConstStaticCell<FrameBuffer> = ConstStaticCell::new(FrameBuffer::new());
    let [mut render_frame, spare_frame] = FrameLease::pair(FRAME_A.take(), FRAME_B.take());
    #[cfg(feature = "target-bench")]
    profiling::target_bench::run(render_frame.buffer());
    #[cfg(feature = "te-trace")]
    spawner.spawn(crate::tasks::te::observe_te(Input::new(p.PIN_21, Pull::None)).unwrap());
    let mut spare_frame = Some(spare_frame);
    let mut lifecycle = FrameLifecycle::new();
    let mut panel_history = PanelHistory::new();
    // Each retained render buffer remembers its own orientation, including
    // inverted modes that share geometry but still require a full repaint.
    let mut rendered_orientations = [None; 2];
    spawner.spawn(crate::tasks::recovery::recovery_task(watchdog).unwrap());

    #[cfg(feature = "ble-obd")]
    spawner.spawn(
        tasks::ble::radio_task(
            dashboard_configuration.config.config().ble,
            tasks::ble::Resources {
                pio: p.PIO0,
                dma: p.DMA_CH1,
                power: p.PIN_23,
                data: p.PIN_24,
                cs: p.PIN_25,
                clock: p.PIN_29,
            },
        )
        .unwrap(),
    );

    /// One-time static residence of the sole initialized SPI/DC/CS owner.
    static FLUSHER: StaticCell<St7789Flusher<'static>> = StaticCell::new();
    let flusher: &'static mut St7789Flusher<'static> = FLUSHER.init(flusher);

    spawner.spawn(display_flush_task(flusher).unwrap());
    log_info!("Display flush task spawned");

    // I2C0 for STEMMA QT encoder (GP4=SDA, GP5=SCL, 400kHz)
    let mut i2c_config = i2c::Config::default();
    i2c_config.frequency = 400_000;
    let i2c = i2c::I2c::new_async(p.I2C0, p.PIN_5, p.PIN_4, Irqs, i2c_config);

    // Spawn encoder task — only starts polling after init is fully complete
    spawner.spawn(encoder_task(i2c).unwrap());
    log_info!("Encoder task spawned");

    let btn_a = Input::new(p.PIN_12, Pull::Up);
    let btn_b = Input::new(p.PIN_13, Pull::Up);
    let btn_x = Input::new(p.PIN_14, Pull::Up);
    let btn_y = Input::new(p.PIN_15, Pull::Up);

    let mut gestures = ControlGestures::new();
    let (startup_profile, mut startup) =
        dashboard_pico2::startup::Startup::from_encoded(&DASHBOARD_STARTUP_PROFILE, Instant::now().as_millis());
    if startup.exit() == Some(dashboard_pico2::startup::Exit::Fault) {
        log_fault!("Startup profile invalid; continuing to dashboard");
    }
    let mut startup_validation = if startup_profile.theme == dashboard_pico2::startup::StartupTheme::Custom {
        dashboard_pico2::view_config::startup_asset::Validator::new(&DASHBOARD_STARTUP_ASSET[..STARTUP_ASSET_LENGTH])
            .ok()
    } else {
        None
    };
    let mut startup_asset = None;
    let startup_validation_started = Instant::now();
    if startup_profile.theme == dashboard_pico2::startup::StartupTheme::Custom && startup_validation.is_none() {
        startup.finish_at(dashboard_pico2::startup::Exit::Fault, Instant::now().as_millis());
        log_fault!("Startup asset header invalid");
    }

    log_info!("Buttons initialized");

    let mut input_tracker = dashboard_pico2::input_trace::InputTracker::new();
    let mut reset_input: Option<(dashboard_pico2::input_trace::Observation, u64)> = None;

    let mut cache_seen = dashboard_pico2::cache_diagnostics::CacheExhaustionSeen::new();
    cache_reporting::report(
        &mut cache_seen,
        dashboard_pico2::cache_diagnostics::CacheExhaustionStatus::from_config(
            dashboard_configuration.config.cache_identity_status(),
        ),
        |cause| log_info!("{}", cause),
    );
    let mut dashboard_cache = DashboardCache::new();
    let mut presentation = dashboard_pico2::presentation::PresentationState::new();
    let mut fps_meter = CompletionRate::new(Instant::now().as_micros(), COMPLETED_FRAMES.load(Ordering::Relaxed));
    let mut last_trace: Option<FrameTrace> = None;
    let mut led_presentation = PresentedLed::new();
    let mut warning_requests = WarningRequests::new();
    let mut last_profile_log = Instant::now();

    let mut core0_work = FrameWorkObservation::EMPTY;

    let mut flush_in_progress = None;

    let mut measurements = DashboardSnapshot::EMPTY;
    let mut quality_transitions = dashboard_pico2::logging::QualityTransitions::new();
    measurements.mode = data_mode();
    let mut reset_requests = ResetRequests::default();

    log_info!("Main loop starting");

    let animation_start = Instant::now();

    let mut measurement_receiver = DASHBOARD_VALUES.dyn_receiver().unwrap();
    #[cfg(feature = "longan-rx12")]
    let mut link_receiver = tasks::acquisition::VEHICLE_LINK.dyn_receiver().unwrap();
    #[cfg(feature = "longan-rx12")]
    let mut vehicle_link = None;
    #[cfg(not(any(feature = "longan-rx12", feature = "ble-obd")))]
    let vehicle_link = None;
    #[cfg(all(feature = "longan-rx12", feature = "frame-trace"))]
    let mut diagnostic_receiver = tasks::acquisition::VEHICLE_DIAGNOSTICS.dyn_receiver().unwrap();
    #[cfg(feature = "frame-trace")]
    let mut frame_window_receiver = tasks::flush::FRAME_WINDOWS.dyn_receiver().unwrap();

    loop {
        let frame_start = Instant::now();
        // Give the SAVING state one normal presentation before maintenance.
        // The immutable ticket also makes changes during that frame explicit.
        let save_this_frame = pending_save.is_some();
        let mut input_work = cpu_profiling::RenderWork::new(cpu_freq_hz);

        let elapsed_ms = animation_start.elapsed().as_millis();
        let blink_on = dashboard_pico2::animations::blink_on(elapsed_ms);

        let controls = &dashboard_configuration.config.config().controls;
        let pressed = [btn_a.is_low(), btn_b.is_low(), btn_x.is_low(), btn_y.is_low()];
        let mut encoder = ENCODER_EVENTS.take_observed();
        // Sample after taking the batch: concurrently accepted observations are eligible.
        let input_ms = Instant::now().as_millis();
        let mut buttons = if startup.active() {
            gestures.update_startup(controls, session.page(), pressed, input_ms)
        } else {
            gestures.update(controls, session.page(), pressed, input_ms)
        };
        startup.consume_inputs(&mut gestures, &mut buttons, &mut encoder, input_ms);
        let input = session.apply(
            &dashboard_configuration.config,
            controls,
            buttons,
            encoder,
            &crate::profiling::LOGS,
            input_ms,
        );
        let consumed_us = Instant::now().as_micros();
        input_tracker.ignore(input.ignored);
        if let Some(observation) = input.observations {
            input_tracker.consume(observation, consumed_us);
        }
        if let Some(observation) = input.reset_observation {
            if let Some((old, consumed)) = &mut reset_input {
                if old.merge(observation) {
                    *consumed = consumed_us;
                } else {
                    input_tracker.ignore(observation.events);
                }
            } else {
                reset_input = Some((observation, consumed_us));
            }
        }

        if input.fps_changed {
            log_info!("FPS: {}", session.fps().label());
        }
        if input.units_changed {
            log_info!("Boost: {}", if session.boost_psi() { "PSI" } else { "BAR" });
        }
        if input.page_changed {
            fps_meter = CompletionRate::new(Instant::now().as_micros(), COMPLETED_FRAMES.load(Ordering::Relaxed));
            log_info!(
                "Page: {}",
                match session.page() {
                    Page::Dashboard => "Dashboard",
                    Page::Debug => "Debug",
                    Page::Logs => "Logs",
                }
            );
        }
        if input.view_changed {
            presentation.reset();
            dashboard_layout = dashboard_pico2::configured_scene::Layout::new(
                &dashboard_configuration.config,
                session.view_id(),
                dashboard_configuration.fault.is_some(),
            )
            .expect("selected validated view");
            warning_pager.pause(input_ms);
            log_info!("View: {}", dashboard_layout.name());
        }
        if input.recovered {
            log_info!("Controls recovered: Dashboard Full");
        }
        session.expire_feedback(input_ms);
        if input.acknowledge_requested {
            let requested = warning_requests.request_presented(led_presentation.warning());
            session.warning_feedback(WarningFeedback::requested(requested), input_ms);
        }
        if input.reset_requested {
            crate::tasks::acquisition::RESET_STATISTICS.signal(reset_requests.request());
            log_info!("Stats reset requested");
        }
        if let Some(snapshot) = measurement_receiver.try_changed() {
            // Observe before raw-sample acceptance: metadata may advance alone.
            cache_reporting::report(&mut cache_seen, snapshot.cache_exhaustion_status(), |cause| {
                log_info!("{}", cause)
            });
            if measurements.accept(snapshot) && reset_requests.acknowledge(measurements.reset_generation) {
                log_info!("Stats reset acknowledged");
                if let Some((observation, consumed_us)) = reset_input.take() {
                    if session.page() == Page::Dashboard {
                        input_tracker.apply(observation, consumed_us, Instant::now().as_micros());
                    } else {
                        input_tracker.ignore(observation.events);
                    }
                }
                session.statistics_acknowledged(Instant::now().as_millis());
            }
        }
        if let Some(feedback) = warning_requests.observe(&measurements) {
            dashboard_pico2::logging::log_warning_rejection(
                &crate::profiling::LOGS,
                feedback,
                Instant::now().as_millis(),
            );
            session.warning_feedback(feedback, Instant::now().as_millis());
        }
        if let Some(command) = warning_requests.pending() {
            // Full preserves the one logical request for an identical retry.
            let _ = crate::tasks::acquisition::WARNING_COMMANDS.try_send(command);
        }
        let now_ms = Instant::now().as_millis();
        quality_transitions.log(&crate::profiling::LOGS, &measurements, now_ms);
        apply_backlight(&mut backlight_pwm, &mut pwm_config, session.backlight());
        apply_indicator(
            &mut rgb_led,
            &mut led_controller,
            &led_presentation,
            session.backlight(),
            dashboard_configuration.config.config(),
        );
        // Brightness is runtime-only. Keep legacy journal fields canonical,
        // preserving saved boost/FPS without writing flash for every click.
        let desired = Settings::new(100, 100, session.boost_psi(), session.fps()).expect("invalid live preferences");
        settings_policy.set(desired, now_ms).expect("settings clock regressed");
        if pending_save.is_none() {
            pending_save = settings_policy.begin(now_ms).expect("invalid save policy");
        }
        let settings_status = settings_policy.status();
        if settings_status != last_settings_status {
            log_info!("Settings: {}", settings_status.label(has_saved_settings));
            last_settings_status = settings_status;
        }
        #[cfg(feature = "longan-rx12")]
        if let Some(link) = link_receiver.try_changed() {
            vehicle_link = Some(link);
        }
        #[cfg(not(feature = "ble-obd"))]
        let vehicle_status = dashboard_pico2::vehicle_status::VehicleStatus::derive(
            cfg!(feature = "longan-rx12"),
            vehicle_link,
            &measurements,
            now_ms,
        );
        #[cfg(feature = "ble-obd")]
        let vehicle_status = dashboard_pico2::vehicle_status::VehicleStatus::from_ble(tasks::ble::snapshot().state);

        let frame_count = COMPLETED_FRAMES.load(Ordering::Relaxed);
        let rate_at = Instant::now().as_micros();
        if fps_meter.sample(rate_at, frame_count).is_err() {
            log_info!("Invalid FPS window; restarting");
            fps_meter = CompletionRate::new(rate_at, frame_count);
        }
        let rate = fps_meter.latest(rate_at);
        let current_fps = rate.map(|v| v.current);
        let average_fps = rate.map(|v| v.average);

        let startup_before = startup.active();
        if startup.active() && startup_validation.is_some() {
            let slice_start = Instant::now();
            while slice_start.elapsed().as_millis() < 3 {
                let checked = startup_validation.as_mut().expect("active validator").step();
                match checked {
                    Ok(true) => {
                        startup_asset = startup_validation.as_ref().and_then(|v| v.finish().ok());
                        startup_validation = None;
                        break;
                    }
                    Ok(false) => {}
                    Err(_) => {
                        startup_validation = None;
                        startup.finish_at(dashboard_pico2::startup::Exit::Fault, Instant::now().as_millis());
                        log_fault!("Startup asset corrupt");
                        break;
                    }
                }
                input_work.checkpoint().await;
            }
            if startup_validation.is_some() && startup_validation_started.elapsed().as_millis() >= 250 {
                startup_validation = None;
                startup.finish_at(dashboard_pico2::startup::Exit::Fault, Instant::now().as_millis());
                log_fault!("Startup asset validation not ready");
            }
        }
        let startup_scene = if startup.active() {
            PresentedScene::capture(
                &dashboard_configuration.config,
                &measurements,
                session.page(),
                session.view_id(),
                None,
                now_ms,
            )
        } else {
            PresentedScene::EMPTY
        };
        startup.advance(
            startup_profile,
            now_ms,
            dashboard_configuration.fault.is_some()
                || vehicle_status == dashboard_pico2::vehicle_status::VehicleStatus::ResetRequired,
            startup_scene.attention,
        );
        if startup_before && !startup.active() {
            gestures.suppress_held();
            presentation.reset();
        }
        let user_overlay = if startup.active() {
            None
        } else {
            session.overlay(&dashboard_configuration.config)
        };
        let warning_page = if !startup.active() && session.page() == Page::Dashboard && user_overlay.is_none() {
            warning_pager.select(
                &dashboard_configuration.config,
                &measurements,
                session.view_id(),
                now_ms,
                blink_on,
            )
        } else {
            warning_pager.pause(now_ms);
            None
        };
        let visible_overlay = Overlay::configured_for_page(session.page(), user_overlay, warning_page);
        let presented_scene = if startup.active() {
            startup_scene.startup(startup_profile.warning_led)
        } else {
            PresentedScene::capture(
                &dashboard_configuration.config,
                &measurements,
                session.page(),
                session.view_id(),
                visible_overlay,
                now_ms,
            )
        };
        input_tracker.exclude_obscured(visible_overlay.and_then(Overlay::warning_phase).is_some());
        let render_start = Instant::now();
        let input_cycles = input_work.finish();
        let mut render_work = cpu_profiling::RenderWork::new(cpu_freq_hz);

        // Resolve once. The queued request and completed history retain this
        // value even when input selects another view during the old transfer.
        let orientation = dashboard_pico2::startup::screen_orientation(
            dashboard_configuration.config.config(),
            startup_profile,
            startup.phase(),
            session.page(),
            session.view_id(),
        );
        let geometry = orientation.geometry();
        let render_idx = render_frame.id().index();
        if rendered_orientations[render_idx] != Some(orientation)
            || panel_history.target_orientation() != Some(orientation)
        {
            dashboard_cache.invalidate(render_idx);
            rendered_orientations[render_idx] = Some(orientation);
        }
        let token = lifecycle.begin(render_frame.id()).expect("render buffer is not free");
        panel_history
            .begin_render_in(token, orientation)
            .expect("invalid render generation");
        let mut display = St7789Renderer::with_geometry(render_frame.buffer(), geometry);

        if startup.active() {
            presentation.reset();
            dashboard_cache.invalidate(render_idx);
            if startup.phase() == dashboard_pico2::startup::Phase::Splash
                && startup_profile.theme == dashboard_pico2::startup::StartupTheme::Custom
            {
                if let Some(asset) = startup_asset {
                    let frame = asset.frame_at(
                        startup.elapsed(now_ms),
                        startup_profile.loop_animation,
                        dashboard_configuration.config.config().reduced_motion,
                    );
                    let mut rows = frame.rows();
                    let mut valid = frame.geometry() == geometry;
                    for row in 0..usize::from(geometry.height()) {
                        if !valid {
                            break;
                        }
                        if rows
                            .next(display.row_bytes_mut(row).expect("bounded startup row"))
                            .is_err()
                        {
                            valid = false;
                            break;
                        }
                        if row % 8 == 7 {
                            render_work.checkpoint().await;
                        }
                    }
                    if !valid {
                        startup.finish_at(dashboard_pico2::startup::Exit::Fault, Instant::now().as_millis());
                        log_fault!("Startup frame invalid");
                        gestures.suppress_held();
                        lifecycle.ready(token).expect("invalid failed startup render");
                        lifecycle.discard(token).expect("invalid unsubmitted startup frame");
                        continue;
                    }
                } else {
                    display.clear(BLACK).ok();
                }
            } else {
                dashboard_pico2::startup::draw(
                    &mut display,
                    startup.phase(),
                    startup_profile,
                    startup.elapsed(now_ms),
                    dashboard_configuration.config.config().reduced_motion,
                    dashboard_pico2::startup::StartupFacts {
                        vehicle: vehicle_status,
                        config_ok: dashboard_configuration.fault.is_none(),
                        settings_loaded: has_saved_settings,
                        configured_sources: dashboard_configuration
                            .config
                            .config()
                            .sources
                            .iter()
                            .filter(|s| s.definition != dashboard_pico2::view_config::DefinitionId::Disabled)
                            .count() as u8,
                    },
                );
            }
            render_work.checkpoint().await;
        } else {
            match session.page() {
                Page::Dashboard => {
                    let readings = presentation.prepare(
                        &dashboard_configuration.config,
                        &measurements,
                        session.view_id(),
                        now_ms,
                        session.boost_psi(),
                    );
                    let scene = DashboardScene {
                        readings: Some(&readings),
                        layout: Some(dashboard_layout),
                        measurements: &measurements,
                        status: vehicle_status,
                        now_ms,
                        blink_on,
                        boost_psi: session.boost_psi(),
                        fps_mode: session.fps(),
                        fps_instant: current_fps.unwrap_or(f32::NAN),
                        fps_average: average_fps.unwrap_or(f32::NAN),
                        backgrounds: [BLACK; 8], // Shared configured renderer owns warning colours.
                        overlay: visible_overlay,
                    };
                    let redraw = dashboard_cache.prepare_in(render_idx, &scene, geometry);
                    redraw.begin(&mut display, &scene);
                    render_work.checkpoint().await;
                    for cell in 0..8 {
                        if redraw.cells & (1 << cell) != 0 {
                            scene.draw_cell(&mut display, cell);
                            render_work.checkpoint().await;
                        }
                    }
                    redraw.finish(&mut display, &scene);
                }

                Page::Debug => {
                    presentation.reset();
                    dashboard_cache.invalidate(render_idx);
                    display.clear(BLACK).ok();
                    render_work.checkpoint().await;
                    let mem_stats = crate::profiling::MemoryStats::collect();
                    let core1 = crate::tasks::CORE1_OBSERVATION.lock(core::cell::Cell::get);
                    let observed_at = Instant::now().as_micros();
                    let core0_stack = mem_stats
                        .stack_used
                        .and_then(|used| memory_kib(used, mem_stats.stack_total));
                    let core1_stack = core1
                        .stack_bytes
                        .and_then(|used| memory_kib(used, crate::tasks::CORE1_STACK_BYTES));

                    let requested_spi_hz = display_spi_config().frequency;
                    let actual_spi_hz = get_actual_spi_freq(embassy_rp::clocks::clk_peri_freq());

                    draw_profiling_page(
                        &mut display,
                        &ProfilingData {
                            current_fps,
                            reset_cause,
                            vehicle_status: vehicle_status.label(),
                            config_fault: dashboard_configuration.fault.is_some(),
                            average_fps,
                            frame_count,
                            trace: last_trace,
                            brightness: session.backlight().brightness(),
                            settings_status: settings_status.label(has_saved_settings),
                            buffer_swaps: BUFFER_SWAPS.load(Ordering::Relaxed),
                            buffer_waits: BUFFER_WAITS.load(Ordering::Relaxed),
                            render_buffer_idx: render_idx,
                            flush_buffer_idx: match FLUSH_BUFFER_IDX.load(Ordering::Relaxed) {
                                index @ 0..=1 => Some(index),
                                _ => None,
                            },
                            core0_stack_used_kb: core0_stack.map(|v| v.0),
                            core0_stack_total_kb: mem_stats.stack_total.div_ceil(1024),
                            core1_stack_used_kb: core1_stack.map(|v| v.0),
                            core1_stack_total_kb: crate::tasks::CORE1_STACK_BYTES / 1024,
                            static_ram_kb: memory_kib(mem_stats.static_ram, mem_stats.ram_total)
                                .expect("valid RAM bounds")
                                .0,
                            ram_total_kb: mem_stats.ram_total / 1024,
                            cpu0_util_percent: core0_work.work(observed_at),
                            cpu1_util_percent: core1.work(observed_at),
                            frame_cycles: core0_work.cycles(observed_at),
                            requested_cpu_hz: dashboard_pico2::clock_profile::REQUESTED_CPU_HZ,
                            configured_cpu_hz: cpu_freq_hz,
                            requested_spi_hz,
                            configured_spi_hz: actual_spi_hz,
                            requested_voltage_mv: dashboard_pico2::clock_profile::VOLTAGE_MV,
                            vreg_setting_mv: vreg_setting_mv(),
                        },
                        controls,
                        &mut render_work,
                    )
                    .await;
                }

                Page::Logs => {
                    presentation.reset();
                    dashboard_cache.invalidate(render_idx);
                    display.clear(BLACK).ok();
                    render_work.checkpoint().await;
                    draw_logs_page(&mut display, session.log_anchor(), controls, &mut render_work).await;
                }
            }
        }

        if session.page() != Page::Dashboard
            && let Some(overlay) = visible_overlay
        {
            overlay.draw(&mut display);
        }

        let render_end = Instant::now();
        let render_cycles = render_work.finish();
        let work_cycles = input_cycles
            .zip(render_cycles)
            .and_then(|(input, render)| input.checked_add(render));

        lifecycle.ready(token).expect("render buffer is not owned");
        let wait_start = Instant::now();
        let next_frame = if let Some(expected) = flush_in_progress.take() {
            let completed = wait_completed(&mut lifecycle, expected).await;
            assert!(led_presentation.complete(expected), "wrong indicator completion");
            startup.completed(expected, Instant::now().as_millis());
            session
                .backlight_mut()
                .frame_completed(expected, Instant::now().as_millis());
            apply_backlight(&mut backlight_pwm, &mut pwm_config, session.backlight());
            apply_indicator(
                &mut rgb_led,
                &mut led_controller,
                &led_presentation,
                session.backlight(),
                dashboard_configuration.config.config(),
            );
            panel_history
                .complete(expected)
                .expect("invalid completed panel generation");
            last_trace = Some(completed.trace);
            completed.lease
        } else {
            spare_frame.take().expect("missing spare framebuffer")
        };
        let blocked_us = wait_start.elapsed().as_micros();
        crate::tasks::recovery::DISPLAY_PENDING.store(false, Ordering::Relaxed);
        if save_this_frame {
            input_tracker.maintenance_gap();
            tasks::flush::publish_input_counts(input_tracker.counters());
            let ticket = pending_save.take().expect("missing save ticket");
            // Both affine leases are owned here and the matching completion
            // has returned. Queue no display work until all owners resume.
            crate::tasks::recovery::RENDER_PROGRESS.fetch_add(1, Ordering::Relaxed);
            let result = tasks::maintenance::run(|permit| settings_flash.save(ticket.settings(), permit)).await;
            settings_policy
                .finish(ticket, result.is_ok(), Instant::now().as_millis())
                .expect("invalid save completion");
            match result {
                Ok(()) => {
                    has_saved_settings = true;
                    log_info!("Settings saved and verified");
                }
                Err(tasks::maintenance::SaveError::Preparation(error)) => log_fault!("Save preparation: {:?}", error),
                Err(tasks::maintenance::SaveError::Operation(error)) => log_settings_error(&error),
            }
            gestures.reset();
            ENCODER_EVENTS.clear();
            if let Some((observation, _)) = reset_input.take() {
                input_tracker.ignore(observation.events);
            }
            // Render again with current wall-clock ages and post-park link
            // quality. Never present this pre-maintenance sensor snapshot.
            lifecycle.discard(token).expect("maintenance retained a live frame");
            dashboard_cache.invalidate(render_idx);
            spare_frame = Some(next_frame);
            continue;
        }
        let reference = panel_history
            .reference_for(orientation)
            .filter(|reference| reference.buffer == next_frame.id());
        let mut plan = if cfg!(feature = "full-frame") || reference.is_none() {
            DamagePlan::full_in(geometry)
        } else {
            DamagePlan::between_in(geometry, next_frame.pixels(), render_frame.pixels())
        };
        if plan.is_empty() && !led_presentation.equivalent(presented_scene) {
            // Identical pixels with a new episode still need completed ownership.
            plan = DamagePlan::full_in(geometry);
        }
        if startup.needs_first_frame()
            && (startup.phase() != dashboard_pico2::startup::Phase::Splash
                || startup_profile.theme != dashboard_pico2::startup::StartupTheme::Custom
                || startup_asset.is_some())
        {
            plan = DamagePlan::full_in(geometry);
        }
        let idle = plan.is_empty();
        if idle {
            input_tracker.no_damage();
        }
        tasks::flush::publish_input_counts(input_tracker.counters());
        let trace = RenderTrace {
            start_us: render_start.as_micros(),
            end_us: render_end.as_micros(),
            queued_us: Instant::now().as_micros(),
            blocked_us,
            sample_us: measurements
                .sensors
                .iter()
                .filter_map(|s| s.sampled_at_ms())
                .min()
                .and_then(|ms| ms.checked_mul(1000)),
            active_cycles: render_cycles,
            input: input_tracker.pending(),
        };
        if idle {
            lifecycle.discard(token).expect("cannot discard active frame");
            assert!(led_presentation.unchanged(presented_scene), "pending indicator at idle");
            session.backlight_mut().frame_unchanged(Instant::now().as_millis());
            apply_backlight(&mut backlight_pwm, &mut pwm_config, session.backlight());
            apply_indicator(
                &mut rgb_led,
                &mut led_controller,
                &led_presentation,
                session.backlight(),
                dashboard_configuration.config.config(),
            );
            spare_frame = Some(next_frame);
            crate::tasks::recovery::DISPLAY_PENDING.store(false, Ordering::Relaxed);
            // Keep the completed reference unchanged and reuse this render buffer.
            // A timed suspension prevents a stationary scene from busy-spinning.
            Timer::after_millis(16).await;
        } else {
            panel_history
                .queue(token, if plan.is_full() { None } else { reference })
                .expect("partial update does not match panel generation");
            lifecycle.queue(token).expect("another frame is still in flight");
            crate::tasks::recovery::DISPLAY_PENDING.store(true, Ordering::Relaxed);
            let request = render_frame.submit_plan_in(token, trace, plan, orientation);
            assert!(
                led_presentation.submit(token, presented_scene),
                "pending indicator submission"
            );
            if startup.phase() != dashboard_pico2::startup::Phase::Splash
                || startup_profile.theme != dashboard_pico2::startup::StartupTheme::Custom
                || startup_asset.is_some()
            {
                startup.submitted(token);
            }
            session.backlight_mut().frame_submitted(token);
            input_tracker.submitted();
            assert!(FLUSH_REQUESTS.try_send(request).is_ok(), "unconsumed frame request");
            BUFFER_SWAPS.fetch_add(1, Ordering::Relaxed);
            wait_started(&mut lifecycle, token).await;
            if cfg!(feature = "serial-display") {
                let completed = wait_completed(&mut lifecycle, token).await;
                assert!(led_presentation.complete(token), "wrong serial indicator completion");
                startup.completed(token, Instant::now().as_millis());
                session
                    .backlight_mut()
                    .frame_completed(token, Instant::now().as_millis());
                apply_backlight(&mut backlight_pwm, &mut pwm_config, session.backlight());
                apply_indicator(
                    &mut rgb_led,
                    &mut led_controller,
                    &led_presentation,
                    session.backlight(),
                    dashboard_configuration.config.config(),
                );
                panel_history.complete(token).expect("invalid serial panel generation");
                crate::tasks::recovery::DISPLAY_PENDING.store(false, Ordering::Relaxed);
                last_trace = Some(completed.trace);
                spare_frame = Some(completed.lease);
            } else {
                flush_in_progress = Some(token);
            }
            render_frame = next_frame;
        }

        let observed_at = Instant::now();
        core0_work = FrameWorkObservation::new(
            observed_at.as_micros(),
            cpu_freq_hz,
            work_cycles,
            (observed_at - frame_start).as_micros(),
        );

        if last_profile_log.elapsed() >= Duration::from_secs(2) {
            #[cfg(feature = "frame-trace")]
            if let Some(report) = frame_window_receiver.try_changed() {
                profiling::telemetry_export::frames(report);
            }
            #[cfg(all(feature = "longan-rx12", feature = "frame-trace"))]
            if let Some((sequence, published_ms, snapshot)) = diagnostic_receiver.try_changed() {
                profiling::telemetry_export::diagnostics(sequence, published_ms, snapshot);
            }
            #[cfg(feature = "te-trace")]
            crate::tasks::te::log_status();
            // Two log_info! lines to fit within 40-char message limit
            if let Some(trace) = last_trace {
                log_info!(
                    "r={}us f={}us t={}us {}fps",
                    trace.render_us(),
                    trace.transfer_observed_us(),
                    trace.total_us(),
                    rate_text(current_fps).as_str(),
                );
            } else {
                log_info!("r=--us f=--us t=--us {}fps", rate_text(current_fps).as_str());
            }
            log_info!(
                "UI:{} Acq:{} sw={} w={}",
                work_text(core0_work.work(Instant::now().as_micros())).as_str(),
                work_text(
                    crate::tasks::CORE1_OBSERVATION
                        .lock(core::cell::Cell::get)
                        .work(Instant::now().as_micros())
                )
                .as_str(),
                BUFFER_SWAPS.load(Ordering::Relaxed),
                BUFFER_WAITS.load(Ordering::Relaxed)
            );
            last_profile_log = Instant::now();
        }

        crate::tasks::recovery::RENDER_PROGRESS.fetch_add(1, Ordering::Relaxed);

        apply_indicator(
            &mut rgb_led,
            &mut led_controller,
            &led_presentation,
            session.backlight(),
            dashboard_configuration.config.config(),
        );
    }
}
